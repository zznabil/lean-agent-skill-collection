# Lean Agent Skills Complete v7.2

Thirty compact skills for engineering, research, communication, documents, interfaces, and quality work.

## Package shape

```text
.codex-plugin/plugin.json
skills/<skill>/SKILL.md
skills/<skill>/agents/openai.yaml
```

The `SKILL.md` files remain vendor-neutral. Each `agents/openai.yaml` file is a thin OpenAI adapter for ChatGPT and Codex metadata and invocation policy.

## Included skills

`architecture`, `brandkit`, `browser-automation`, `cli-design`, `debug`, `experiment`, `frontend`, `gauntlet-loop`, `get-it-done`, `grilling`, `handoff`, `implement`, `merge-conflicts`, `monitor`, `office-files`, `plan`, `project-context`, `prototype`, `python`, `reasoning`, `release`, `repo-map`, `research`, `review`, `skill-design`, `teach`, `test`, `triage`, `wait-what`, `writing`

Manual-only skills in this package: `gauntlet-loop`, `get-it-done`, `grilling`, `handoff`, `wait-what`

## v7.2 focus

v7.2 absorbs the strongest ARC-agent harness lessons as generic doctrine: raw evidence stays authoritative, beliefs remain graded, uncertain actions carry predictions, model and reality gates stay separate, and trusted skills do not self-promote.

## V7.2 focus

V7.2 absorbs selected Compound Engineering mechanics without importing its competing lifecycle: right-sized planning, stable decisions, outcome-spine skill design, live cross-host evaluation, reviewer identity receipts, verified solution learning, staged experiment scoring, and explicit residual-work disposition.

## Install

Install this ZIP as a skills-only plugin where supported, or copy the directories under `skills/` into a user or repository skill directory.

- Keep `AGENTS.md` in the trusted project root when included.
- Keep `ENGINEERING-CORE.md` beside `AGENTS.md` for material engineering work.
- Do not install overlapping profiles together.
- Other agent hosts can ignore `agents/openai.yaml` and use the same `SKILL.md` files.

See `VALIDATION.json` for static checks. Runtime activation depends on the installed host and available tools.
