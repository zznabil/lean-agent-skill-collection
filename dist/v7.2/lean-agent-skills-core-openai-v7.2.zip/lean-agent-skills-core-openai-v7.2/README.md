# Lean Agent Skills Core v7.2

Nine compact skills for communication, planning, research, review, and long-horizon execution.

## Package shape

```text
.codex-plugin/plugin.json
skills/<skill>/SKILL.md
skills/<skill>/agents/openai.yaml
```

The `SKILL.md` files remain vendor-neutral. Each `agents/openai.yaml` file is a thin OpenAI adapter for ChatGPT and Codex metadata and invocation policy.

## Included skills

`gauntlet-loop`, `get-it-done`, `handoff`, `plan`, `reasoning`, `research`, `review`, `skill-design`, `wait-what`

Manual-only skills in this package: `gauntlet-loop`, `get-it-done`, `handoff`, `wait-what`

## v7.2 focus

v7.2 adds evidence-guided action: falsifiable expectations, cheap separating tests, mismatch stopping, trajectory challenge, and fair benchmark disclosure without adding a routed skill.

## V7.2 focus

V7.2 absorbs selected Compound Engineering mechanics without importing its competing lifecycle: right-sized planning, stable decisions, outcome-spine skill design, live cross-host evaluation, reviewer identity receipts, verified solution learning, staged experiment scoring, and explicit residual-work disposition.

## Install

Install this ZIP as a skills-only plugin where supported, or copy the directories under `skills/` into a user or repository skill directory.

- Keep `AGENTS.md` in the trusted project root when included.
- Keep `ENGINEERING-CORE.md` beside `AGENTS.md` for material engineering work.
- Do not install overlapping profiles together.
- Other agent hosts can ignore `agents/openai.yaml` and use the same `SKILL.md` files.

See `VALIDATION.json` for static checks. Runtime activation depends on the installed host and available tools.
