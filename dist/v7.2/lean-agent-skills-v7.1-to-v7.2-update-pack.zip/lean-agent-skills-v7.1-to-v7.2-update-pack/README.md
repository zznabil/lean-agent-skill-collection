# Lean V7.1 to V7.2 update pack

Use only the directory matching the installed exact V7.1 profile. Copy its contents over that profile. This pack is not a standalone collection. The overlay includes updated plugin metadata, validation, checksums, and every changed runtime file, so the resulting tree matches V7.2.

V7.2 absorbs selected Compound Engineering mechanics into existing Lean authorities. It adds no skills and no external integrations.
