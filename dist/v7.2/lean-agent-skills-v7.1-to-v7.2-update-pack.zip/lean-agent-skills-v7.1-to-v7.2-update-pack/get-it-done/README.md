# Get It Done Pack v7.2

Long-horizon execution, adversarial acceptance, and clear user-facing reporting.

## Package shape

```text
.codex-plugin/plugin.json
skills/<skill>/SKILL.md
skills/<skill>/agents/openai.yaml
```

The `SKILL.md` files remain vendor-neutral. Each `agents/openai.yaml` file is a thin OpenAI adapter for ChatGPT and Codex metadata and invocation policy.

## Included skills

`gauntlet-loop`, `get-it-done`, `wait-what`

Manual-only skills in this package: `gauntlet-loop`, `get-it-done`, `wait-what`

## v7.2 focus

v7.2 turns unresolved uncertainty into the next cheapest separating test, stops dependent work on mismatch, reviews the full trajectory at plateaus, and keeps model and reality acceptance distinct.

## V7.2 focus

V7.2 absorbs selected Compound Engineering mechanics without importing its competing lifecycle: right-sized planning, stable decisions, outcome-spine skill design, live cross-host evaluation, reviewer identity receipts, verified solution learning, staged experiment scoring, and explicit residual-work disposition.

## Install

Install this ZIP as a skills-only plugin where supported, or copy the directories under `skills/` into a user or repository skill directory.

- Keep `AGENTS.md` in the trusted project root when included.
- Keep `ENGINEERING-CORE.md` beside `AGENTS.md` for material engineering work.
- Do not install overlapping profiles together.
- Other agent hosts can ignore `agents/openai.yaml` and use the same `SKILL.md` files.

See `VALIDATION.json` for static checks. Runtime activation depends on the installed host and available tools.
