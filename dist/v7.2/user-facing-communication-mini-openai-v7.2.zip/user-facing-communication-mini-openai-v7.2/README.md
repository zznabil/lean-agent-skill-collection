# User Facing Communication Mini v7.2

Three compact skills for clear replies, teaching, and prose artifacts.

## Package shape

```text
.codex-plugin/plugin.json
skills/<skill>/SKILL.md
skills/<skill>/agents/openai.yaml
```

The `SKILL.md` files remain vendor-neutral. Each `agents/openai.yaml` file is a thin OpenAI adapter for ChatGPT and Codex metadata and invocation policy.

## Included skills

`teach`, `wait-what`, `writing`

Manual-only skills in this package: `wait-what`

## v7.2 focus

v7.2 is a package-coherence release. The three communication skills remain byte-identical to V7.

## Install

Install this ZIP as a skills-only plugin where supported, or copy the directories under `skills/` into a user or repository skill directory.

- Keep `AGENTS.md` in the trusted project root when included.
- Do not install overlapping profiles together.
- Other agent hosts can ignore `agents/openai.yaml` and use the same `SKILL.md` files.

See `VALIDATION.json` for static checks. Runtime activation depends on the installed host and available tools.
